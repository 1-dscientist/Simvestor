public interface Transaction extends Investment{
	boolean isTransaction();
	String toStringTransaction();
}
