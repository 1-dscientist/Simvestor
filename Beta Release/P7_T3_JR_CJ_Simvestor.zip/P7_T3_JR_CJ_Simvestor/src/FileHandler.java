// Saves files in .sim format because it sounds nice

public class FileHandler {

}
