public class Trader extends Stocks {

	public Trader()
	{
		
	}
	
	// METHODS
}
