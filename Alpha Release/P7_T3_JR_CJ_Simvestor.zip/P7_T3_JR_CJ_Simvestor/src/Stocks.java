public class Stocks {

	public Stocks() {
		// TODO Auto-generated constructor stub
	}

}
