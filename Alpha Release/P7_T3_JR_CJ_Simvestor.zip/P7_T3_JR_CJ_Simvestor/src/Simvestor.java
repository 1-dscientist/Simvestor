import java.awt.Container;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

// The Simvestors

public class Simvestor extends JPanel {

	public Simvestor() {
		// TODO Auto-generated constructor stub
	}
	
	public void paintComponent(Graphics g)
	  {
	    super.paintComponent(g);
	    int width = getWidth();    
	    int height = getHeight();
	  }

	  public static void main(String[] args)
	  {
	    JFrame Simvestor = new JFrame("Simvestor");
	    Simvestor.setBounds(300, 300, 1600, 900);
	    Simvestor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    Simvestor.setVisible(true);
	  }
}